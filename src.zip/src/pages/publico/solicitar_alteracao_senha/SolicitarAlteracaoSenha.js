import styles from './SolicitarAlteracaoSenha.module.scss';
const SolicitarAlteracaoSenha = () => {
    return (
        <div className={styles.solicitar_alteracao_senha}>
            <h1>Welcome to the Solicitar Alteração de Senha Page</h1>
        </div>
    )
}
export default SolicitarAlteracaoSenha;