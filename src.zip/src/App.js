import Rotas from './routes/Rotas';

function App() {
  return (
    <Rotas />
  );
}

export default App;
